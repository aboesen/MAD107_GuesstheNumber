import UIKit

var magicNumber = 15

print("Let's Play Higher or Lower!")
print("Pick a number from 0 - 20!")
var userNumber = 16

if(magicNumber > userNumber)
{
    print("Too Low! Try again.")
}
if(magicNumber < userNumber)
{
    print("Too High! Try again.")
}
if(magicNumber == userNumber)
{
    print("You've guessed the number!")
}
